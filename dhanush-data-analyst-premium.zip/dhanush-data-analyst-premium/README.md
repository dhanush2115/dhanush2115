<div align="center">

# 👋 DHANUSH KUMAR M

<a href="https://github.com/dhanush2115">
  <img src="https://readme-typing-svg.demolab.com?font=JetBrains+Mono&weight=700&size=28&duration=2800&pause=900&color=00E5FF&center=true&vCenter=true&width=760&lines=Aspiring+Data+Analyst;SQL+%7C+Python+%7C+Power+BI+%7C+Excel;Turning+Raw+Data+Into+Insights;Building+Data-Driven+Projects" alt="Typing animation"/>
</a>

<br/>

<img src="https://komarev.com/ghpvc/?username=dhanush2115&label=PROFILE+VIEWS&color=00e5ff&style=for-the-badge" alt="Profile views"/>
<a href="https://github.com/dhanush2115"><img src="https://img.shields.io/github/followers/dhanush2115?style=for-the-badge&label=FOLLOWERS&color=111827" alt="Followers"/></a>
<a href="https://github.com/dhanush2115"><img src="https://img.shields.io/github/stars/dhanush2115?style=for-the-badge&label=STARS&color=111827" alt="Stars"/></a>

<br/><br/>

<a href="https://github.com/dhanush2115/dhanush-data-analyst-premium">
<img src="https://img.shields.io/badge/🌐%20PREMIUM%20PORTFOLIO-LIVE%20WEBSITE-00E5FF?style=for-the-badge"/>
</a>

</div>

---

## 🧭 Data Analyst Identity

> **Aspiring Data Analyst** focused on transforming raw data into clean analysis, interactive dashboards, and actionable insights.

🎓 B.Tech Information Technology  
📊 SQL • Python • Power BI • Excel  
🤖 Currently exploring Machine Learning & Tableau  
📍 Vellore, Tamil Nadu, India

---

## ⚡ Analytics Stack

<div align="center">

<img src="https://skillicons.dev/icons?i=python,mysql,git,github,vscode" height="55"/>

<br/><br/>

<img src="https://img.shields.io/badge/SQL-0EA5E9?style=for-the-badge&logo=mysql&logoColor=white"/>
<img src="https://img.shields.io/badge/Python-3776AB?style=for-the-badge&logo=python&logoColor=white"/>
<img src="https://img.shields.io/badge/Power%20BI-F2C811?style=for-the-badge&logo=powerbi&logoColor=111827"/>
<img src="https://img.shields.io/badge/Excel-217346?style=for-the-badge&logo=microsoftexcel&logoColor=white"/>
<img src="https://img.shields.io/badge/Pandas-150458?style=for-the-badge&logo=pandas&logoColor=white"/>
<img src="https://img.shields.io/badge/NumPy-013243?style=for-the-badge&logo=numpy&logoColor=white"/>
<img src="https://img.shields.io/badge/Tableau-Learning-5B21B6?style=for-the-badge"/>
<img src="https://img.shields.io/badge/Machine%20Learning-Learning-7C3AED?style=for-the-badge"/>

</div>

---

## 📊 Skills Dashboard

| Skill | Level | Focus |
|---|---:|---|
| SQL | ████████████████████ 90% | Queries, joins, CTEs, analytics |
| Python | █████████████████░░░ 80% | Pandas, NumPy, automation |
| Power BI | █████████████████░░░ 80% | Dashboards, DAX, KPIs |
| Excel | ████████████████████ 90% | Cleaning, formulas, reports |
| Machine Learning | ███████████░░░░░░░░░ 55% | Learning |
| Tableau | ██████████░░░░░░░░░░ 50% | Learning |

---

## 🔄 My Data Analytics Workflow

```text
RAW DATA
   │
   ▼
DATA CLEANING
   │
   ▼
SQL / DATABASE
   │
   ▼
PYTHON + PANDAS
   │
   ▼
EXPLORATORY ANALYSIS
   │
   ▼
POWER BI / EXCEL
   │
   ▼
VISUALIZATION
   │
   ▼
BUSINESS INSIGHTS
   │
   ▼
DATA-DRIVEN DECISIONS
```

---

## 🚀 Featured Data Analytics Projects

### 🚆 Train Travel Management System
**SQL • MySQL • Database Management**

Railway-focused database project covering passengers, trains, routes, bookings, payments, and analytical SQL queries.

[🔗 View Project](https://github.com/dhanush2115)

### 📱 Social Media Analytics
**SQL • MySQL • Analytics**

Analyze posts, users, engagement, likes, comments, and performance metrics using SQL.

[🔗 View Project](https://github.com/dhanush2115)

### 👨‍💼 Employee Analytics
**SQL • MySQL**

Explore employee salary, department, city, joining date, top salaries, and business-oriented queries.

[🔗 View Project](https://github.com/dhanush2115)

### 📈 Sales Dashboard
**Excel • Power BI**

Interactive dashboard concept for sales KPIs, revenue trends, product performance, and regional analysis.

[🔗 View Project](https://github.com/dhanush2115)

### 🎓 Student Analytics
**SQL • Power BI**

Student-performance analysis with attendance, marks, departments, and dashboard-ready metrics.

[🔗 View Project](https://github.com/dhanush2115)

---

## 📈 GitHub Analytics

<div align="center">

<img height="180" src="https://github-readme-stats.vercel.app/api?username=dhanush2115&show_icons=true&theme=tokyonight&hide_border=true&rank_icon=github&include_all_commits=true" />
<img height="180" src="https://github-readme-stats.vercel.app/api/top-langs/?username=dhanush2115&layout=compact&theme=tokyonight&hide_border=true&langs_count=8" />

<br/><br/>

<img src="https://streak-stats.demolab.com?user=dhanush2115&theme=tokyonight&hide_border=true" />

</div>

---

## 🏆 GitHub Trophies

<div align="center">

<img src="https://github-profile-trophy.vercel.app/?username=dhanush2115&theme=tokyonight&no-frame=true&no-bg=true&margin-w=8&row=1&column=7" />

</div>

---

## 🐍 Contribution Snake

<div align="center">

<img src="https://raw.githubusercontent.com/dhanush2115/dhanush2115/output/github-contribution-grid-snake.svg" alt="Contribution Snake"/>

</div>

---

## 🌐 Connect With Me

<div align="center">

<a href="https://linkedin.com/in/dhanushkumar2721/">
<img src="https://img.shields.io/badge/LinkedIn-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white"/>
</a>
<a href="mailto:dhanushm95872@gmail.com">
<img src="https://img.shields.io/badge/Email-EA4335?style=for-the-badge&logo=gmail&logoColor=white"/>
</a>
<a href="https://github.com/dhanush2115">
<img src="https://img.shields.io/badge/GitHub-111827?style=for-the-badge&logo=github&logoColor=white"/>
</a>

</div>

---

<div align="center">

### `DATA → ANALYSIS → INSIGHT → IMPACT`

<img src="https://capsule-render.vercel.app/api?type=waving&color=0:00e5ff,50:6366f1,100:a855f7&height=120&section=footer"/>

</div>
