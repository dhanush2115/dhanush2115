# Premium GitHub + Website Setup

## 1. GitHub profile README
Create a public repository named exactly:

`dhanush2115`

Copy the root `README.md` into that repository.

## 2. Snake automation
Copy `.github/workflows/snake.yml` into the profile repository.

Then:
```bash
git add README.md .github/workflows/snake.yml
git commit -m "Create premium data analyst profile"
git push origin main
```

The GitHub Action generates the contribution snake.

## 3. Run the website locally

Open a terminal in the `website` folder.

If Python is installed:
```bash
python -m http.server 5500
```

Then open:
`http://localhost:5500`

Or use VS Code + Live Server.

## 4. Publish the website
The website is static HTML/CSS/JS, so it can be hosted on GitHub Pages, Netlify or Vercel.

For GitHub Pages:
- Create a repository such as `dhanush-portfolio`
- Upload the contents of `website/`
- Settings → Pages
- Deploy from the `main` branch

## 5. Project live-demo links
The project cards currently point to your GitHub profile. Replace each project's `url` in `website/script.js` with the actual repository URL or deployed demo URL when those projects are published.
