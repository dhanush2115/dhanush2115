const projects = [
 {name:"Train Travel Management System",cat:"sql",tag:"DATABASE",desc:"Railway database for trains, passengers, routes, bookings and payment analytics.",tech:"MySQL • SQL • ER Modeling",url:"https://github.com/dhanush2115"},
 {name:"Social Media Analytics",cat:"sql",tag:"ANALYTICS",desc:"SQL analysis of users, posts, likes, comments and engagement performance.",tech:"MySQL • SQL • Aggregations",url:"https://github.com/dhanush2115"},
 {name:"Employee Analytics",cat:"sql",tag:"SQL",desc:"Salary, department, city and joining-date analysis using practical business queries.",tech:"MySQL • SQL • CASE • GROUP BY",url:"https://github.com/dhanush2115"},
 {name:"Sales Intelligence Dashboard",cat:"bi",tag:"DASHBOARD",desc:"Dashboard concept for revenue, KPIs, products and regional sales performance.",tech:"Power BI • DAX • Data Modeling",url:"https://github.com/dhanush2115"},
 {name:"Student Analytics Dashboard",cat:"bi",tag:"EDUCATION",desc:"Student performance, attendance and department metrics designed for decision support.",tech:"Power BI • SQL • KPIs",url:"https://github.com/dhanush2115"},
 {name:"Excel Sales Report",cat:"excel",tag:"EXCEL",desc:"Clean reporting workflow with formulas, summaries and management-ready metrics.",tech:"Excel • Cleaning • Reporting",url:"https://github.com/dhanush2115"}
];

const grid = document.querySelector("#projectGrid");
function render(filter="all"){
  grid.innerHTML = projects.filter(p=>filter==="all"||p.cat===filter).map((p,i)=>`
  <article class="project glass">
    <div class="project-top"><span class="project-num">0${i+1}</span><span class="tag">${p.tag}</span></div>
    <h3>${p.name}</h3><p>${p.desc}</p>
    <div class="project-tech">${p.tech}</div>
    <a href="${p.url}" target="_blank" rel="noreferrer">VIEW PROJECT ↗</a>
  </article>`).join("");
}
render();
document.querySelectorAll(".filter").forEach(btn=>btn.addEventListener("click",()=>{
 document.querySelectorAll(".filter").forEach(b=>b.classList.remove("active"));
 btn.classList.add("active"); render(btn.dataset.filter);
}));

const phrases=["SQL • Python • Power BI • Excel","Data Cleaning & Exploration","Business Intelligence & Dashboards","Turning Questions Into Insights"];
let pi=0,ci=0,deleting=false;
function type(){
 const t=phrases[pi];
 document.querySelector("#typing").textContent=t.slice(0,ci);
 if(!deleting){ci++;if(ci>t.length){deleting=true;setTimeout(type,1000);return}}
 else{ci--;if(ci<0){deleting=false;pi=(pi+1)%phrases.length;ci=0}}
 setTimeout(type,deleting?35:60);
}
type();

document.querySelector("#themeBtn").addEventListener("click",()=>document.body.classList.toggle("light"));

const observer=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting)e.target.classList.add("show")}),{threshold:.12});
document.querySelectorAll(".reveal").forEach(e=>observer.observe(e));

async function github(){
 try{
  const r=await fetch("https://api.github.com/users/dhanush2115");
  if(!r.ok) throw new Error();
  const d=await r.json();
  document.querySelector("#githubName").textContent=d.name||d.login;
  document.querySelector("#githubBio").textContent=d.bio||"Public GitHub profile and analytics projects.";
  document.querySelector("#repos").textContent=d.public_repos;
  document.querySelector("#followers").textContent=d.followers;
  document.querySelector("#following").textContent=d.following;
 }catch(e){
  document.querySelector("#githubName").textContent="dhanush2115";
  document.querySelector("#githubBio").textContent="GitHub stats will appear when the API is available.";
 }
}
github();
